import h5py
import torch
import shutil
import numpy as np
import cv2
import os
import scipy.io
import math
from PIL import Image

path = "local_minimum_save"

lists = os.listdir(path)

lists = [item for item in lists if not item.startswith('.') and item.endswith('.pp')]
for item in lists:
    img = cv2.imread(os.path.join(path, item))
    cv2.imwrite(os.path.join(path, item.split('.')[0]+'.jpg'), img)