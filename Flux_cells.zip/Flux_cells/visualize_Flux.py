# coding:utf-8
import sys
import os

import warnings

#from pool_model import CSRNet
from crop_half import crop_half
from utils import save_checkpoint, save_true_pred, caculate_precision_baseline, caculate_recall_baseline, get_flux

import torch.nn.functional as F
import torch
import torch.nn as nn
from torch.autograd import Variable
from torchvision import datasets, transforms
import os
import numpy as np
import argparse
import json
import cv2
import dataset
import time
import math
from PIL import Image
from image import *
import scipy.io
import scipy.misc as misc
import os
from hed_model import HED
from rate_model import RATEnet
from fpn import AutoScale
from unet import U_Net
from vgg import VGG
from centerloss import CenterLoss
import gc
import matplotlib.pyplot as plt
plt.switch_backend('agg')
from matplotlib import cm

from find_contours import findmaxcontours
from inference_flux import trans_n8, flux_to_skl
from inference_from_direction_map import direction_to_cells_new
# from Fluxgenerate import radExtract, skel2seg

parser = argparse.ArgumentParser(description='PyTorch CSRNet')
parser.add_argument('--model_id', default=0, type=int, help='id of trained model')
warnings.filterwarnings('ignore')
g_save = '../datasets/cells/magnitude_and_angle'
if not os.path.exists(g_save):
    os.mkdir(g_save)

def main():
    global args, best_prec1
   
    best_prec1 = 1e6
    #best_game = 1e6
    args = parser.parse_args()
    args.batch_size = 1
    args.start_epoch = 0
    args.epochs = 1
    args.workers = 4
    args.seed = time.time()
    args.print_freq = 200
    args.infer_thresh = 0.6
    args.task = "save_file_baseline_Cells"
    args.result = "save_result_Cells_unet32(AdaK+Flip+1)"
    if not os.path.exists(args.task):
        os.mkdir(args.task)

    if not os.path.exists(args.result):
        os.mkdir(args.result)

    global trancos_train_mask, trancos_test_mask

    with open('./Cellstest.npy', 'rb') as outfile:
        val_list = np.load(outfile).tolist()
    print(val_list)
    print(len(val_list), val_list[0],len(val_list))


    density_value = 3
    os.environ['CUDA_VISIBLE_DEVICES'] = "2"
    # model = HED()
    model = U_Net()
    model = nn.DataParallel(model, device_ids=[0])
    model = model.cuda()

    rate_model = 1
    class_model = VGG('VGG16')
    criterion = nn.CrossEntropyLoss(reduction='none').cuda()


    args.pre = './saved_model/train32_unet(AdaK+Flip+2)/model_best.pth.tar'
    #args.pre = None
    if args.pre:
        if os.path.isfile(args.pre):
            print("=> loading checkpoint '{}'".format(args.pre))
            checkpoint = torch.load(args.pre)
            args.start_epoch = 0
            best_prec1 = checkpoint['best_prec1']

            model_dict = model.state_dict()
            pre_val = checkpoint['state_dict']
            pre_val = {k: v for k, v in pre_val.items() if k in model_dict}
            model_dict.update(pre_val)
            model.load_state_dict(model_dict)

            print("=> loaded checkpoint '{}' (epoch {})"
                  .format(args.pre, checkpoint['epoch']))
            print('Best_prec1:', best_prec1)
        else:
            print("=> no checkpoint found at '{}'".format(args.pre))

    for epoch in range(args.epochs):

        times_model, times_post = validate(val_list, model, class_model, rate_model, criterion, args.task, density_value, epoch)

        times_model = np.array(times_model, dtype=np.float32)
        time_model = times_model.mean()
        times_post = np.array(times_post, dtype=np.float32)
        time_post = times_post.mean()
        with open('pr_txt/time_log.txt', 'a+') as f:
            f.write(
                '* Time_Model {}, * Time_Post {}, * Time_Total {}\n'.format(time_model, time_post, time_model+time_post))
            print(
                '* Time_Model {}, * Time_Post {}, * Time_Total {}'.format(time_model, time_post, time_model+time_post))




def validate(Pre_data, model, classifier, rate_model, criterion, task_id, density_value, epoch):
    print('begin test')
    test_loader = torch.utils.data.DataLoader(
        dataset.listDataset_Cell_Val(Pre_data, task_id,
                            shuffle=False,
                            transform=transforms.Compose([
                                transforms.ToTensor(), transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                                                            std=[0.229, 0.224, 0.225]),
                            ]), train=False),batch_size=1)

    model.eval()

    mae = []
    mse = []
    error = []

    visi = []

    precisions = []
    recalls = []
    times_model = []
    times_post = []
    with torch.no_grad():
        for i, (img, target, k, fname, img_raw) in enumerate(test_loader):
            print(fname)
            pre_count = 0

            target =  target.type(torch.FloatTensor).cuda()
            img = img.cuda()

            torch.cuda.synchronize()
            start = time.time()

            Hed_result_5 = model(img, target)[0]
            torch.cuda.synchronize()
            end = time.time()
            computation = end - start
            times_model.append(computation)

            # #UNet
            # Hed_result_5 = model(img, target)[0]
            # #CSRNet
            # Hed_result_5 = model(img, target)
            # #FCN, SegNet, BL
            # Hed_result_5 = model(img)

            original_distance_map = Hed_result_5.detach().cpu().numpy()
            original_distance_map = original_distance_map.squeeze(0)
            img_raw = img_raw.cpu().numpy().squeeze(0)

            start = time.time()
            mask, extract_skl = flux_to_skl(original_distance_map, args.infer_thresh)
            end = time.time()
            post_time = end - start
            times_post.append(post_time)


            k = k.numpy().squeeze(0)
            print(img_raw.shape)
            with h5py.File(os.path.join(args.result, fname[0]), 'w') as f:
                f['flux'] = original_distance_map
                f['gt'] = k
                f['img'] = img_raw

            Gt_count = k.sum()

            mae.append(abs(pre_count - Gt_count))
            error.append(pre_count - Gt_count)
            mse.append(abs(pre_count - Gt_count) * abs(pre_count - Gt_count))

        
    mae = np.array(mae)
    mse =np.array(mse)
    error = np.array(error)


    return times_model, times_post


if __name__ == '__main__':
    main()