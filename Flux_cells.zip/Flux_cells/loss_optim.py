import numpy as np

def forward(self, bottom, top):
    # L1 and L2 distance
    self.distL1 = bottom[0].data - bottom[1].data
    self.distL2 = self.distL1**2
    # the amount of positive and negative pixels
    regionPos = (bottom[2].data>0)
    regionNeg = (bottom[2].data==0)
    sumPos = np.sum(regionPos)
    sumNeg = np.sum(regionNeg)
    # balanced weight for positive and negative pixels
    self.weightPos[0][0] = sumNeg/float(sumPos+sumNeg)*regionPos
    self.weightPos[0][1] = sumNeg/float(sumPos+sumNeg)*regionPos
    self.weightNeg[0][0] = sumPos/float(sumPos+sumNeg)*regionNeg
    self.weightNeg[0][1] = sumPos/float(sumPos+sumNeg)*regionNeg
    # total loss
    top[0].data[...] = np.sum(self.distL2*(self.weightPos + self.weightNeg)) / bottom[0].num / 2. / np.sum(self.weightPos + self.weightNeg)

def backward(self, top, propagate_down, bottom):
    bottom[0].diff[...] = self.distL1*(self.weightPos + self.weightNeg) / bottom[0].num
    bottom[1].diff[...] = 0
    bottom[2].diff[...] = 0
