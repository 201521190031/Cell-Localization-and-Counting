import os
import sys
import numpy as np
from scipy import spatial as ss
import pdb

import cv2
from Utils_Hungarian import hungarian, read_pred_and_gt, AverageMeter, AverageCategoryMeter

result_dir ='../save_results/Cells/UNet32(AdaK+Flip+2)_0.9/'
if not os.path.exists(result_dir):
    os.mkdir(result_dir)


gt_file = result_dir + 'gt_loc.txt'
pred_file = result_dir + 'pred_loc.txt'

flagError = False
id_std = [i for i in range(101, 201, 1)]

num_classes = 6


def compute_metrics(dist_matrix, match_matrix, pred_num, gt_num, sigma, level):
    for i_pred_p in range(pred_num):
        pred_dist = dist_matrix[i_pred_p,:]
        match_matrix[i_pred_p,:] = pred_dist<=sigma
        
    tp, assign = hungarian(match_matrix)
    fn_gt_index = np.array(np.where(assign.sum(0)==0))[0]
    tp_pred_index = np.array(np.where(assign.sum(1)==1))[0]
    tp_gt_index = np.array(np.where(assign.sum(0)==1))[0]
    fp_pred_index = np.array(np.where(assign.sum(1)==0))[0]

    tp = tp_pred_index.shape[0]
    fp = fp_pred_index.shape[0]
    fn = fn_gt_index.shape[0]


    return tp,fp,fn


def cal_pr(pred_file, gt_file, id_std):
    
    cnt_errors = {'mae':AverageMeter(),'mse':AverageMeter(),'nae':AverageMeter(),}
    metrics_s = {'tp':AverageMeter(), 'fp':AverageMeter(), 'fn':AverageMeter(), }


    pred_data, gt_data = read_pred_and_gt(pred_file, gt_file)
    for i_sample in id_std:
        print(i_sample) 
        # init               
        gt_p,pred_p,fn_gt_index,tp_pred_index,fp_pred_index= [],[],[],[],[]
        tp_s,fp_s,fn_s = [0,0,0]

        if gt_data[i_sample]['num'] ==0 and pred_data[i_sample]['num'] !=0:            
            pred_p =  pred_data[i_sample]['points']
            fp_pred_index = np.array(range(pred_p.shape[0]))
            fp_s = fp_pred_index.shape[0]
            fp_l = fp_pred_index.shape[0]

        if pred_data[i_sample]['num'] ==0 and gt_data[i_sample]['num'] !=0:
            gt_p = gt_data[i_sample]['points']
            level = gt_data[i_sample]['level']
            fn_gt_index = np.array(range(gt_p.shape[0]))
            fn_s = fn_gt_index.shape[0]
            fn_l = fn_gt_index.shape[0]
        

        if gt_data[i_sample]['num'] !=0 and pred_data[i_sample]['num'] !=0:
            pred_p =  pred_data[i_sample]['points']    
            gt_p = gt_data[i_sample]['points']
            sigma_s = gt_data[i_sample]['sigma'][:,0]
            sigma_l = gt_data[i_sample]['sigma'][:,1]
            level = gt_data[i_sample]['level']        
        
            # dist
            dist_matrix = ss.distance_matrix(pred_p,gt_p,p=2)
            match_matrix = np.zeros(dist_matrix.shape,dtype=bool)

            # sigma_s and sigma_l
            tp_s,fp_s,fn_s = compute_metrics(dist_matrix,match_matrix,pred_p.shape[0],gt_p.shape[0],sigma_s,level)


        metrics_s['tp'].update(tp_s)
        metrics_s['fp'].update(fp_s)
        metrics_s['fn'].update(fn_s)
        

        gt_count,pred_cnt = gt_data[i_sample]['num'],pred_data[i_sample]['num']
        s_mae = abs(gt_count-pred_cnt)
        s_mse = (gt_count-pred_cnt)*(gt_count-pred_cnt)
        cnt_errors['mae'].update(s_mae)
        cnt_errors['mse'].update(s_mse)

        if gt_count !=0:
            s_nae = abs(gt_count-pred_cnt)/gt_count
            cnt_errors['nae'].update(s_nae)
    
    ap_s = metrics_s['tp'].sum/(metrics_s['tp'].sum+metrics_s['fp'].sum+1e-20)
    ar_s = metrics_s['tp'].sum/(metrics_s['tp'].sum+metrics_s['fn'].sum+1e-20)
    f1m_s = 2*ap_s*ar_s/(ap_s+ar_s)


    print('-----Localization performance-----')
    print('AP_small: '+str(ap_s))
    print('AR_small: '+str(ar_s))
    print('F1m_small: '+str(f1m_s))


    mae = cnt_errors['mae'].avg
    mse = np.sqrt(cnt_errors['mse'].avg)
    nae = cnt_errors['nae'].avg

    print('-----Counting performance-----')
    print('MAE: '+str(mae))
    print('MSE: '+str(mse))
    print('NAE: '+str(nae))

    
    return mae, ap_s, ar_s, f1m_s


if __name__ == '__main__':
    cal_pr(pred_file, gt_file, id_std)
