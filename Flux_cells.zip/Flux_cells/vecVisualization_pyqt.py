# -*- coding: utf-8 -*-       
import os
import sys
import scipy.io as sio
import math
import matplotlib.pyplot as plt
from matplotlib import cm
import numpy as np
from PyQt5 import QtGui, QtCore, QtWidgets
import cv2


class OpenFile(QtWidgets.QMainWindow):
    def __init__(self):
        QtWidgets.QWidget.__init__(self)

        self.setGeometry(300, 300, 250, 50)
        self.setWindowTitle('Open File')
        self.statusBar()
        self.setFocus()

        exit = QtWidgets.QAction(QtGui.QIcon(), 'Open', self)
        exit.setShortcut('Ctrl+O')
        exit.setStatusTip('Open new File')
        exit.triggered.connect(self.showDialog)

        menubar = self.menuBar()
        file = menubar.addMenu('&File')
        file.addAction(exit)

    def showDialog(self):

        filename = QtWidgets.QFileDialog.getOpenFileName(self, 'open file dialog', '../save_cells/transxy',
                                                         'Mat files(*.mat)')
        file_name = '%s' % filename[0]
        file = sio.loadmat(file_name)
        data = file['GTcls']
        norm = data[1, :, :] ** 2 + data[0, :, :] ** 2
        norm = np.sqrt(norm)
        angle = 180 / math.pi * np.arctan2(data[1, :, :], data[0, :, :])
        # angle = angle*(norm>0.45)
        # cv2.imwrite('E:/mag.png',255*(norm>0.45).astype(np.uint8))
        fig = plt.figure(file_name, figsize=(5, 8))
        ax1 = fig.add_subplot(211)
        ax1.set_title('Magnitude of the predicted vector')
        ax1.set_autoscale_on(True)
        im1 = ax1.imshow(norm, cmap=cm.jet)
        plt.colorbar(im1, shrink=0.9)
        ax2 = fig.add_subplot(212)
        ax2.set_title('Direction of the predicted vector')
        ax2.set_autoscale_on(True)
        im2 = ax2.imshow(angle, cmap=cm.jet)
        plt.colorbar(im2, shrink=0.9)
        plt.show()


app = QtWidgets.QApplication(sys.argv)
of = OpenFile()
of.show()
sys.exit(app.exec_())
