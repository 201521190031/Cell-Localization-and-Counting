import numpy as np
import os
import scipy.io
import argparse

parser = argparse.ArgumentParser(description='PyTorch CSRNet')

parser.add_argument('--num_train', default=32, type=int, help='number of train_samples')
parser.add_argument('--random', default=True, type=bool, help='whether random sample training data')

args = parser.parse_args()

# trancos_train_path='/home/dl/projects/synchronous/chenfeng_code/TRANCOS_v3/TRANCOS/train_data/images/'
# trancos_val_path='/home/dl/projects/synchronous/chenfeng_code/TRANCOS_v3/TRANCOS/val_data/images/'
# trancos_test_path='/home/dl/projects/synchronous/chenfeng_code/TRANCOS_v3/TRANCOS/test_data/images/'
# mask_path='/home/dl/projects/synchronous/chenfeng_code/TRANCOS_v3/images/'

Cellstrain_path = '../datasets/cells/transxy/'
# Cellstest_path = '../datasets/cells/test_data/'


feature_path = './save_feature_attention_mean_B/'
feature_test_path = './save_feature_attention_mean_B/'
# train_list = []
# for filename in os.listdir(shanghaiAtrain_path):
#     if filename.split('.')[1] == 'jpg':
#         train_list.append(shanghaiAtrain_path+filename)
#
# train_list.sort()
# np.save('./ShanghaiAtrain.npy', train_list)
# print(train_list)
#
#
# test_list = []
# for filename in os.listdir(shanghaiAtest_path):
#     if filename.split('.')[1] == 'jpg':
#         test_list.append(shanghaiAtest_path+filename)
# test_list.sort()
# np.save('./ShanghaiAtest.npy', test_list)
# print(test_list)
n = args.num_train
random = args.random

train_list = []
for filename in os.listdir(Cellstrain_path):
    if filename.split('.')[1] == 'h5' and not filename.startswith('.'):
        train_list.append(Cellstrain_path + filename)

train_list.sort()
test_list = train_list[-100:]
train_list = train_list[:100]
if random:
    np.random.shuffle(train_list)
train_list_copy = train_list.copy()
train_list = train_list_copy[:n]

np.save('./Cellstrain.npy', train_list)
#print(len(train_list))
print(train_list)

# val_list = test_list
val_list = train_list_copy[n:2*n]
# for filename in os.listdir(Cellstest_path):
#     if filename.split('.')[1] == 'h5':
#         test_list.append(Cellstest_path + filename)

# test_list.sort()
np.save('./Cellsval.npy', val_list)
print((val_list))

np.save('./Cellstest.npy', test_list)
# test_list= []
# test_list = train_list_copy[-11:]
# # CellsCenter_path = os.path.join(Cellstest_path.split('test_data')[0], 'mat_gt')
# # for filename in os.listdir(Cellstest_path):
# #     if filename.split('.')[1] == 'h5':
# #         center_list.append(os.path.join(CellsCenter_path ,filename.split('.')[0] + '.mat'))

# # center_list.sort()
# np.save('./Cellstest.npy', test_list)
# print(test_list)

# for file in center_list:
#     Gt_data = scipy.io.loadmat(file)
#     print(len(Gt_data['coordinate']))