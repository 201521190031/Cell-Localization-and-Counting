import sys
import os

import warnings

#from pool_model import CSRNet
from crop_half import crop_half
from utils import save_checkpoint

import torch.nn.functional as F
import torch
import torch.nn as nn
from torch.autograd import Variable
from torchvision import datasets, transforms
import os
import numpy as np
import argparse
import json
import cv2
import dataset
import time
import math
from PIL import Image
from image import *
import scipy.io
import scipy.misc as misc
import os
from hed_model import HED
from rate_model import RATEnet
from centerloss import CenterLoss
import gc
import matplotlib.pyplot as plt

from find_contours import findmaxcontours

parser = argparse.ArgumentParser(description='PyTorch CSRNet')
warnings.filterwarnings('ignore')

def main():
    global args, best_prec1

    best_prec1 = 1e6
    best_game = 1e6
    args = parser.parse_args()
    args.original_lr = 1e-4
    args.lr =  2 *1e-4
    lr = 1e-4
    lr_cent = 0.1
    args.rate_lr = 0.01
    args.batch_size = 1
    args.start_epoch = 0

    args.momentum = 0.95
    args.decay = 5 * 1e-4
    args.start_epoch = 0
    args.epochs = 1
    args.steps = [-1, 1, 100, 150]
    args.scales = [1, 1, 1, 1]
    args.workers = 4
    args.seed = time.time()
    args.print_freq = 200
    args.task = "save_file_baseline_trancos"

    '''
    with open(args.train_json, 'r') as outfile:        
        train_list = np.load(outfile).tolist()
    with open(args.test_json, 'r') as outfile:       
        val_list = np.load(outfile).tolist()
    '''

    global trancos_train_mask, trancos_test_mask
    with open('./Cellstrain.npy', 'rb') as outfile:
        train_list = np.load(outfile).tolist()

    with open('./Cellstest.npy', 'rb') as outfile:
        val_list = np.load(outfile).tolist()
    print(len(train_list), train_list[0],len(val_list))
    # density_value = args.density_value
    density_value = 3
    os.environ['CUDA_VISIBLE_DEVICES'] = "0"
    # model = CSRNet()
    model = HED()
    model = nn.DataParallel(model, device_ids=[0])
    model = model.cuda()

    # rate_model = RATEnet()
    # rate_model = nn.DataParallel(rate_model, device_ids=[0])
    # rate_model = rate_model.cuda()
    rate_model = 1
    # criterion = nn.MSELoss(size_average=False).cuda()

    criterion = nn.CrossEntropyLoss(reduction='none').cuda()
    center_loss = CenterLoss(num_classes=1, feat_dim=1, use_gpu=True)
    optimizer = torch.optim.Adam(
        [
            {'params': model.module.conv1.parameters(), 'lr': args.lr},
            {'params': model.module.conv2.parameters(), 'lr': args.lr},
            {'params': model.module.conv3.parameters(), 'lr': args.lr},
            {'params': model.module.conv4.parameters(), 'lr': args.lr},
            {'params': model.module.conv5.parameters(), 'lr': args.lr},
            {'params': model.module.cd1.parameters(), 'lr': args.lr},
            {'params': model.module.cd2.parameters(), 'lr': args.lr},
            {'params': model.module.cd3.parameters(), 'lr': args.lr},
            {'params': model.module.cd4.parameters(), 'lr': args.lr},
            {'params': model.module.cd5.parameters(), 'lr': args.lr},
            {'params': model.module.up2.parameters(), 'lr': args.lr},
            {'params': model.module.up3.parameters(), 'lr': args.lr},
            {'params': model.module.up4.parameters(), 'lr': args.lr},
            {'params': model.module.up5.parameters(), 'lr': args.lr},
            {'params': model.module.rd2.parameters(), 'lr': args.lr},
            {'params': model.module.rd3.parameters(), 'lr': args.lr},
            {'params': model.module.rd4.parameters(), 'lr': args.lr},
            {'params': model.module.rd5.parameters(), 'lr': args.lr},
            {'params': model.module.dsn1.parameters(), 'lr': args.lr * 0.1},
            {'params': model.module.dsn2.parameters(), 'lr': args.lr * 0.1},
            {'params': model.module.dsn3.parameters(), 'lr': args.lr * 0.1},
            {'params': model.module.dsn4.parameters(), 'lr': args.lr * 0.1},
            {'params': model.module.dsn5.parameters(), 'lr': args.lr * 0.1},
            {'params': model.module.dsn6.parameters(), 'lr': args.lr * 0.1},
            # {'params': model.module.conv1_1.parameters(), 'lr': args.lr},
            # {'params': model.module.conv1_2.parameters(), 'lr': args.lr},
            # {'params': model.module.conv1_3.parameters(), 'lr': args.lr},
            # {'params': model.module.conv1_4.parameters(), 'lr': args.lr},
            # {'params': model.module.conv1_5.parameters(), 'lr': args.lr},
            # {'params': model.module.conv1_6.parameters(), 'lr': args.lr},
            # {'params': rate_model.module.parameters(), 'lr': args.rate_lr},
        ], lr=args.lr,weight_decay=args.decay)

    # optimizer = torch.optim.Adam(model.parameters(), args.lr,
    #                             weight_decay=args.decay)

    args.pre = './save_file_baseline_trancos/model_best.pth.tar'
    #args.pre = None
    if args.pre:
        if os.path.isfile(args.pre):
            print("=> loading checkpoint '{}'".format(args.pre))
            checkpoint = torch.load(args.pre)
            args.start_epoch = checkpoint['epoch']
            best_prec1 = checkpoint['best_prec1']

            model_dict = model.state_dict()
            pre_val = checkpoint['state_dict']
            # print(pre_val.items())
            pre_val = {k: v for k, v in pre_val.items() if k in model_dict}
            model_dict.update(pre_val)
            model.load_state_dict(model_dict)

            # optimizer.load_state_dict(checkpoint['optimizer'])
            print("=> loaded checkpoint '{}' (epoch {})"
                  .format(args.pre, checkpoint['epoch']))
        else:
            print("=> no checkpoint found at '{}'".format(args.pre))

    print(best_prec1)
    refine_best_mae = 10 * 500
    best_game = 6.78
    #ori_data = ori_preloaddata(train_list, 0)
    #Pre_data_train = pre_data(train_list, train=True)
    for epoch in range(args.start_epoch, args.epochs):
        start = time.time()
        adjust_learning_rate(optimizer, epoch)
        start = time.time()
        #train(train_list, model, rate_model, criterion, center_loss, optimizer, epoch, args.task, density_value,
              #lr_cent, lr)

        end_1 = time.time()
        prec1, visi = validate(val_list, model, rate_model, criterion, args.task, density_value)
        end_2 = time.time()
        print("train time:",end_1-start,"test time:",end_2-end_1)
        #is_best = prec1 < best_prec1
        #is_best = game < best_game
        best_prec1 = min(prec1, best_prec1)
        #best_game = min(game,best_game)
        #is_best = True
        print(' * best MAE {mae:.3f} '
              .format(mae=best_prec1))
        #print("best game1:", best_game)

        # save_checkpoint({
        #     'epoch': epoch + 1,
        #     'arch': args.pre,
        #     'state_dict': model.state_dict(),
        #     # 'rate_state_dict': rate_model.state_dict(),
        #     'best_prec1': best_prec1,
        #     'optimizer': optimizer.state_dict(),
        # }, visi, is_best, args.task)
        # end = time.time()
        


def crop(d, g):
    g_h, g_w = g.size()[2:4]
    d_h, d_w = d.size()[2:4]

    d1 = d[:, :, abs(int(math.floor((d_h - g_h) / 2.0))):abs(int(math.floor((d_h - g_h) / 2.0))) + g_h,
         abs(int(math.floor((d_w - g_w) / 2.0))):abs(int(math.floor((d_w - g_w) / 2.0))) + g_w]
    return d1


def choose_crop(output, target):
    if (output.size()[2] > target.size()[2]) | (output.size()[3] > target.size()[3]):
        output = crop(output, target)
    if (output.size()[2] > target.size()[2]) | (output.size()[3] > target.size()[3]):
        output = crop(output, target)
    if (output.size()[2] < target.size()[2]) | (output.size()[3] < target.size()[3]):
        target = crop(target, output)
    if (output.size()[2] < target.size()[2]) | (output.size()[3] < target.size()[3]):
        target = crop(target, output)
    return output, target


def stn(theta, x):
    matrix = Variable(torch.Tensor([[[1, 0, 0], [0, 1, 0]]])).cuda()

    matrix = matrix.float()

    matrix = matrix * theta
    # New_x = F.upsample_bilinear(x,()

    grid = F.affine_grid(matrix, (x.size()[0], x.size()[1], int(x.size()[2] * theta), int(x.size()[3] * theta)))
    new = F.grid_sample(x, grid)

    # print(x.size(),new.size())
    return new


def stn_reverse(theta, x):
    matrix = Variable(torch.Tensor([[[1, 0, 0], [0, 1, 0]]])).cuda()

    matrix = matrix.float()

    matrix = matrix / theta
    # New_x = F.upsample_bilinear(x,()

    grid = F.affine_grid(matrix, (x.size()[0], x.size()[1], int(x.size()[2]), int(x.size()[3])))
    new = F.grid_sample(x, grid)
    return new


def distance_generate(img_size, k, lamda, crop_size):
    #distance = max(1.0, 1.0 * lamda)
    time_start = time.time()


    distance = 1.0
    new_size = [0, 1]

    new_size[0] = img_size[2] * lamda
    new_size[1] = img_size[3] * lamda

    d_map = (np.zeros([int(new_size[0]), int(new_size[1])]) + 255).astype(np.uint8)
    gt = np.nonzero(k)

    if len(gt) == 0:
        distance_map = np.zeros([int(new_size[0]), int(new_size[1])])
        distance_map[:, :] = 10
        return new_size, distance_map

    # print(k,gt_data,gt,lamda)
    for o in range(0, len(gt)):
        x = int(max(1, gt[o][1].numpy() * lamda))
        y = int(max(1, gt[o][2].numpy() * lamda))
        # print(len(gt),x,y)
        if x >= new_size[0] - 1 or y >= new_size[1] - 1:
            # print(o)
            continue
        d_map[x][y] = d_map[x][y] - 255

    distance_map = cv2.distanceTransform(d_map, cv2.DIST_L2, 5)

    distance_map[(distance_map >= 0) & (distance_map < 1)] = 0
    distance_map[(distance_map >= 1) & (distance_map < 2)] = 1
    distance_map[(distance_map >= 2) & (distance_map < 3)] = 2
    distance_map[(distance_map >= 3) & (distance_map < 4)] = 3
    distance_map[(distance_map >= 4) & (distance_map < 5 * distance)] = 4
    distance_map[(distance_map >= 5 * distance) & (distance_map < 6 * distance)] = 5
    distance_map[(distance_map >= 6 * distance) & (distance_map < 8 * distance)] = 6
    distance_map[(distance_map >= 8 * distance) & (distance_map < 12 * distance)] = 7
    distance_map[(distance_map >= 12 * distance) & (distance_map < 18 * distance)] = 8
    distance_map[(distance_map >= 18 * distance) & (distance_map < 28 * distance)] = 9
    distance_map[(distance_map >= 28 * distance)] = 10

    time_end = time.time()

    return new_size, distance_map


def mask_generate(distance_map, distance_mask):
    #distance_map = distance_map / np.max(distance_map) * 255
    distance_mask[(distance_mask <= 42)] = 0
    distance_mask[(distance_mask > 42)] = 1

    gray = distance_mask.astype(np.uint8)
    Thresh = 0
    ret, binary = cv2.threshold(gray, Thresh, 255, cv2.THRESH_BINARY_INV)
    contours, hierarchy = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    temp = np.ones(gray.shape, np.uint8) * 0
    c_max = []
    max_area = 0
    max_cnt = 0
    for i in range(len(contours)):
        cnt = contours[i]
        area = cv2.contourArea(cnt)
        # find max countour
        if (area > max_area):
            if (max_area != 0):
                c_min = []
                c_min.append(max_cnt)
                cv2.drawContours(temp, c_min, -1, (0, 0, 0), cv2.FILLED)
            max_area = area
            max_cnt = cnt
        else:
            c_min = []
            c_min.append(cnt)
            cv2.drawContours(temp, c_min, -1, (0, 0, 0), cv2.FILLED)
    c_max.append(max_cnt)
    cv2.drawContours(temp, c_max, -1, (1, 1, 1), thickness=-1)
    timg = cv2.bitwise_and(distance_map, distance_map, mask=temp)

    # timg = timg / np.max(timg) * 255
    # cv2.imwrite("timg2.jpg",timg)
    return temp, timg

def count_distance(input_img):
    input_img = input_img.squeeze(0).squeeze(0).detach().cpu().numpy()
    scipy.misc.imsave('./density_best_refine.pgm', input_img)
    f = os.popen('./extract_local_minimum_return_xy ./density_best_refine.pgm 250 ./density_best_refine.pgm density_best_refine.pp')
    count = f.readlines()
    count = float(count[0].split('=')[1])

    return count



def bce2d(input, target):
    n, c, h, w = input.size()
    # assert(max(target) == 1)

    probility = F.softmax(input).cuda()
    start = time.time()
    distance_pro = Variable(torch.zeros(n, c, h, w)).cuda()
    end_1 = time.time()
    distance_pro[:, 0, :, :] = torch.abs(target - 0).cuda()
    distance_pro[:, 1, :, :] = torch.abs(target - 1).cuda()
    distance_pro[:, 2, :, :] = torch.abs(target - 2).cuda()
    distance_pro[:, 3, :, :] = torch.abs(target - 3).cuda()
    distance_pro[:, 4, :, :] = torch.abs(target - 4).cuda()
    distance_pro[:, 5, :, :] = torch.abs(target - 5).cuda()
    distance_pro[:, 6, :, :] = torch.abs(target - 6).cuda()
    distance_pro[:, 7, :, :] = torch.abs(target - 7).cuda()
    distance_pro[:, 8, :, :] = torch.abs(target - 8).cuda()
    distance_pro[:, 9, :, :] = torch.abs(target - 9).cuda()
    distance_pro[:, 10, :, :] = torch.abs(target - 10).cuda()
    end_2 = time.time()

    weight = ((distance_pro + 1) * probility).cuda()
    weight = torch.sum(weight, 1)
    weight = weight.resize(n * h * w)
    log_p = F.log_softmax(input.transpose(1, 2).transpose(2, 3).contiguous().resize(n * h * w, 11)).cuda()
    trans = target.resize(n * h * w).cuda()
    loss = torch.mean(-1 * log_p[range(n * h * w), trans] * weight).cuda()
    end_3 = time.time()
    #print(6*(end_3-start), 6*(end_1-start), 6*(end_2-end_1),6*(end_3-end_2))
    return loss


def nl(input, target, criterion):
    n,c,h,w = input.size()
    probility= F.softmax(input).cuda()
    distance_pro = Variable(torch.zeros(n,c,h,w)).cuda()
    for i in range(c):
        distance_pro[:,i,:,:] = torch.abs(target-i).cuda()
    weight = ((distance_pro+1)*probility).cuda()
    weight = torch.sum(weight,1).resize(n*h*w).cuda()
    #print(input.shape, target.shape,weight.shape)

    loss = criterion(input,target).resize(n*h*w) * weight

    loss = torch.mean(loss)
    return loss


def save_img(img, path):
    img_save = img.mul(255).byte()
    img_save = img_save.cpu().numpy().squeeze(0).transpose((1, 2, 0))
    im = Image.fromarray(img_save)
    im.save(path)


def validate(Pre_data, model, rate_model, criterion, task_id, density_value):
    print('begin test')
    # Pre_data = pre_data(val_list,train=False)

    test_loader = torch.utils.data.DataLoader(
        dataset.listDataset_trancos(Pre_data, task_id,
                            shuffle=False,
                            transform=transforms.Compose([
                                transforms.ToTensor(), transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                                                            std=[0.229, 0.224, 0.225]),
                            ]), train=False),batch_size=1)

    model.eval()

    mae = 0
    mse = 0
    original_mae = 0
    visi = []
    # eval_path =  "../UCF-QNRF_ECCV18/Test/"
    # eval_list = []
    # for file_name in os.listdir(eval_path):
    #     if file_name.split('.')[1] == 'jpg':
    #         eval_list.append(file_name)
    # eval_list.sort()

    log_data_test = []
    scale_map = [1]

    list_class = []

    Gmae = 0
    for i, (img, target, k, fname, sigma_map) in enumerate(test_loader):
        start = time.time()
        pre_count = 0
        img = img.cuda()
        mask = mask.type(torch.FloatTensor).cuda()

        img = img * mask
        target = target.cuda()

        Hed_result_5 = model(img, target, refine_flag=False)[5]
        Hed_result_5 = Hed_result_5*mask
        original_distance_map = torch.max(F.softmax(Hed_result_5), 1, keepdim=True)[1].cuda()
        pre_count = count_distance(original_distance_map)

        #Gmae += GAME(k, fname)
        #print(pre_0.shape,  pre_1.shape, pre_up.shape, original_distance_map.shape, target.shape)
        Gt_count = torch.sum(k).item()

        mae += abs(pre_count - Gt_count)
        mse += abs(pre_count - Gt_count) * abs(pre_count - Gt_count)
        end = time.time()
        if i % 32 == 0:
            # print(pre_count_crop.shape,distance_map_gt.shape)
            visi.append([img.data.cpu().numpy(), original_distance_map.data.cpu().numpy(),
                         target.unsqueeze(0).data.cpu().numpy(), fname])
            print(
                i, fname[0], "Gt:", Gt_count, "pre_count:", pre_count, mae/(i+1), Gmae/(i+1))
        #print("all",end-start,"loca:",end_1-start_1)

    mae = mae / len(test_loader)
    Gmae = Gmae/len(test_loader)
    mse = math.sqrt(mse/len(test_loader))
    original_mae = original_mae / len(test_loader)
    print(' * MAE {mae:.3f} '
          .format(mae=mae))
    print ('GMAE',Gmae)
    print("mse",mse)
    # print("original_mae",original_mae)

    return mae, visi


def adjust_learning_rate(optimizer, epoch):
    """Sets the learning rate to the initial LR decayed by 10 every 30 epochs"""

    # if epoch > 100:
    #     args.lr = 1e-4
    # if epoch > 300:
    #     args.lr = 1e-5


    # for i in range(len(args.steps)):
    #
    #     scale = args.scales[i] if i < len(args.scales) else 1
    #
    #     if epoch >= args.steps[i]:
    #         args.lr = args.lr * scale
    #         if epoch == args.steps[i]:
    #             break
    #     else:
    #         break
    # for param_group in optimizer.param_groups:
    #     param_group['lr'] = args.lr


class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


if __name__ == '__main__':
    main()