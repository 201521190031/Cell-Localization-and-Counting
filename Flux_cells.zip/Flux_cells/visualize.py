# coding:utf-8
import sys
import os

import warnings

#from pool_model import CSRNet
from crop_half import crop_half
from utils import save_checkpoint, save_true_pred, caculate_precision_baseline, caculate_recall_baseline, get_flux

import torch.nn.functional as F
import torch
import torch.nn as nn
from torch.autograd import Variable
from torchvision import datasets, transforms
import os
import numpy as np
import argparse
import json
import cv2
import dataset
import time
import math
from PIL import Image
from image import *
import scipy.io
import scipy.misc as misc
import os
from hed_model import HED
from rate_model import RATEnet
from fpn import AutoScale
from unet import U_Net
from vgg import VGG
from csrnet import CSRNet
from FCN import FCN16s
from SegNet import SegNet
from BL import *
from centerloss import CenterLoss
import gc
import matplotlib.pyplot as plt
plt.switch_backend('agg')
from matplotlib import cm

from find_contours import findmaxcontours
from inference_flux import trans_n8, flux_to_skl
# from Fluxgenerate import radExtract, skel2seg

parser = argparse.ArgumentParser(description='PyTorch CSRNet')
parser.add_argument('--model_id', default=0, type=int, help='id of trained model')
warnings.filterwarnings('ignore')
g_save = '../datasets/cells/magnitude_and_angle'
if not os.path.exists(g_save):
    os.mkdir(g_save)

def main():
    global args, best_prec1
   
    best_prec1 = 1e6
    #best_game = 1e6
    args = parser.parse_args()
    args.batch_size = 1
    args.start_epoch = 0
    args.epochs = 1
    args.workers = 4
    args.seed = time.time()
    args.print_freq = 200
    args.infer_thresh = 0.6
    args.task = "save_file_baseline_Cells"
    args.result = "save_result_Cells_UNet32(AdaK+Flip+2)"
    if not os.path.exists(args.task):
        os.mkdir(args.task)

    if not os.path.exists(args.result):
        os.mkdir(args.result)

    global trancos_train_mask, trancos_test_mask

    with open('./Cellstest.npy', 'rb') as outfile:
        val_list = np.load(outfile).tolist()
    print(val_list)
    print(len(val_list), val_list[0],len(val_list))


    density_value = 3
    os.environ['CUDA_VISIBLE_DEVICES'] = "0"
    # model = HED()
    model = U_Net()
    # model = FCN16s()
    # model = SegNet(3, 2)
    # model = vgg19()
    # model = CSRNet()
    model = nn.DataParallel(model, device_ids=[0])
    model = model.cuda()

    rate_model = 1
    class_model = VGG('VGG16')
    criterion = nn.CrossEntropyLoss(reduction='none').cuda()

    
    args.pre = './saved_model/train32_unet(AdaK+Flip+2)/model_best.pth.tar'
    #args.pre = None
    if args.pre:
        if os.path.isfile(args.pre):
            print("=> loading checkpoint '{}'".format(args.pre))
            checkpoint = torch.load(args.pre)
            args.start_epoch = 0
            best_prec1 = checkpoint['best_prec1']

            model_dict = model.state_dict()
            pre_val = checkpoint['state_dict']
            pre_val = {k: v for k, v in pre_val.items() if k in model_dict}
            model_dict.update(pre_val)
            model.load_state_dict(model_dict)
            # for k:v in model_dict:
            #     print('k:',k)
            print("=> loaded checkpoint '{}' (epoch {})"
                  .format(args.pre, checkpoint['epoch']))
            print('Best_prec1:', best_prec1)
        else:
            print("=> no checkpoint found at '{}'".format(args.pre))

    for epoch in range(args.epochs):
        start = time.time()

        end_1 = time.time()
        # prec1, visi, precisions, recalls = validate(val_list, model, rate_model, criterion, args.task, density_value, epoch)
        validate(val_list, model, class_model, rate_model, criterion, args.task, density_value, epoch)

def direction_generate(img_size,k, lamda):
    gt = np.argwhere(k>0)
    new_size = (int(img_size[0]*lamda),int(img_size[1]*lamda))
    skl = np.zeros(new_size)
    for o in range(0, len(gt)):
        x = int(max(1, gt[o][0].numpy() * lamda))
        y = int(max(1, gt[o][1].numpy() * lamda))
        # print(len(gt),x,y)
        if x >= new_size[0] - 1 or y >= new_size[1] - 1:
            # print(o)
            continue
        skl[x][y] = 1

    flux, mask = get_flux(skl)
    return flux, mask


def count_distance(input_image, input_pred, gt, fname):
    input_image = input_image.squeeze(0)
    #print(input_image.shape)
    gt = gt.numpy()
    gt = np.squeeze(gt)
    gt_loc = np.array(list(np.where(gt==1))).transpose((1,0))
    
    input_pred = input_pred.squeeze(0)
    #分割mask和骨架提取
    mask, extract_skl = flux_to_skl(input_pred, args.infer_thresh)

    _, count = cv2.connectedComponents(extract_skl)
    return np.max(count)


def validate(Pre_data, model, classifier, rate_model, criterion, task_id, density_value, epoch):
    print('begin test')
    test_loader = torch.utils.data.DataLoader(
        dataset.listDataset_Cell_Val(Pre_data, task_id,
                            shuffle=False,
                            transform=transforms.Compose([
                                transforms.ToTensor(), transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                                                            std=[0.229, 0.224, 0.225]),
                            ]), train=False),batch_size=1)

    model.eval()
    # classifier.eval()

    mae = []
    mse = []
    error = []
    mae_pred = []
    mse_pred = []
    original_mae = 0
    original_mae_pred = 0
    visi = []

    Gmae = 0
    precisions = []
    recalls = []
    times = []
    rate = 2
    with torch.no_grad():
        for i, (img, target, k, fname, img_raw) in enumerate(test_loader):
            start = time.time()
            print(fname)
            pre_count = 0
            # imgs = imgs.squeeze(0)
            # targets = targets.squeeze(0)
            # ks = ks.squeeze(0)
            # img_raws = img_raws.squeeze(0)

            # sizes = torch.max(classifier(imgs),1)[1]
            # original_maps = []
            # img_rsize = []
            # for img, target, k, img_raw, size in zip(imgs, targets, ks, img_raws, sizes):
            #     img = img.unsqueeze(0)
            #     img_size = (img.shape[2], img.shape[3])
            #     if size == 1:
            #         img = F.upsample_bilinear(img, (int(img.size()[2] * rate), int(img.size()[3] * rate)))
            #         img_raw = cv2.resize(img_raw, (int(img_raw.shape[0]*rate), int(img_raw.shape[1]*rate)))
            #         target, mask = direction_generate(img_size, k, rate)
            #         target = (torch.from_numpy(target))
            #         print('Rsize')
            target =  target.type(torch.FloatTensor).cuda()
            img = img.cuda()

            # Hed_result_5 = model(img, target, refine_flag=False)[5]
            torch.cuda.synchronize()
            start = time.time()
            #UNet
            Hed_result_5 = model(img, target)[0]
            # #CSRNet
            # Hed_result_5 = model(img, target)
            #FCN, SegNet, BL
            
            # Hed_result_5 = model(img)
            torch.cuda.synchronize()
            end = time.time()
            computation = end - start
            times.append(computation)
            original_distance_map = Hed_result_5.detach().cpu().numpy()
            original_distance_map = original_distance_map.squeeze(0)
            img_raw = img_raw.cpu().numpy().squeeze(0)
            # img_raw= img_raw.squeeze(0)
            # original_maps.append(original_distance_map)
            # img_rsize.append(img_raw)

            # original_maps = np.array(original_maps)
            k = k.numpy().squeeze(0)
            print(img_raw.shape)
            with h5py.File(os.path.join(args.result, fname[0]), 'w') as f:
                f['flux'] = original_distance_map
                f['gt'] = k
                f['img'] = img_raw

            Gt_count = k.sum()

            mae.append(abs(pre_count - Gt_count))
            error.append(pre_count - Gt_count)
            mse.append(abs(pre_count - Gt_count) * abs(pre_count - Gt_count))

            end = time.time()
            
        mae = np.array(mae)
        # Gmae = Gmae/len(test_loader)
        mse =np.array(mse)
        # original_mae = original_mae / len(test_loader)
        error = np.array(error)

        times = np.array(times)

        original_mae_pred = original_mae_pred / len(test_loader)

        with open('./logs/val_logs/vallogt20.txt', 'a+') as f:
            wstr = 'Model_id:{id:d},  Epoch:{epoch:d} * MAE {mae:.3f} \
            ,* MSE {mse:.3f}, * STD {std:.3f}, Time:{time}'.format(id=args.model_id, \
                epoch=epoch+1, mae=np.mean(mae), mse=math.sqrt(np.mean(mse)), \
                std = np.std(mae), time = np.mean(times))
            f.write(wstr+'\n')
            f.write('Epoch:{}, * MAE {} \n* MSE {}\n *ERROR {}\n'.format(epoch+1, mae, mse, error))
            print(wstr)

        # return mae, visi, precisions, recalls


if __name__ == '__main__':
    main()