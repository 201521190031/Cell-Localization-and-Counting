import h5py
import torch
import shutil
import numpy as np
import cv2
import os
import scipy.io
import math
from PIL import Image

filenames = ['./Cellstest.npy']

def main():
    dotsum = []
    for name in filenames:
        with open(name, 'rb') as outfile:
            data_list = np.load(outfile).tolist()
        print(data_list)
        for name in data_list:
            img = Image.open(name.replace('/new_target/', '/new_source/').replace('_dots_','_').replace('.h5','.png')).convert('RGB')
            gt_file = h5py.File(name, 'r')
            kpoint = np.array(gt_file['kpoint'])
            print("num:", kpoint.sum())
            dotsum.append(kpoint.sum())
            gt = np.array(list(np.where(kpoint))).transpose((1,0))
            name = name.split('/')[-1]
            print(name)
            visualize_gt(img, gt, name)

    dotsum = np.array(dotsum)
    print(dotsum.mean())


def visualize_gt(input_image, gt, fname):
    input_image = np.squeeze(input_image, 0)
    #cv2.imwrite(fname[0].split('.')[0]+'im.bmp', input_image)
    #input_image = input_image.transpose((1, 2, 0))
    ori_gt = gt.copy()
    gt = gt.tolist()
    ori_gt = ori_gt.tolist()

    true_positive = 0
    true_positive_crop = 0
    number_other = 0

    # img_path = "../ShanghaiTech_Crowd_Counting_Dataset_baseline/part_A_final/test_data/images/"+fname[0]
    # paper_img = cv2.imread(img_path)

    #input_img = cv2.imread("./ori_caculate_acu.jpg")
    # sigma_map = geneate_knn_map(gt, input_img)
    canvas_pred = input_image.copy()
    canvas_gt = input_image.copy()
    print(canvas_gt.shape)
    # min_index = 0


    # for i in range(len(pred_xy_ori)):

    #     center_x = int(pred_xy_ori[i][1])
    #     center_y = int(pred_xy_ori[i][0])

    #     min_distance = 1e8

    #     if refine_flag == True:
    #         if center_x > crop_size[0] and center_x < crop_size[0] + crop_size[2] and center_y >crop_size[
    #             1] and center_y < crop_size[1] + crop_size[3]:
    #             number_other += 1
    #             continue

    #     cv2.circle(canvas_pred, (int(center_x), int(center_y)), 1, (0, 255, 0), -1)
    #     #cv2.circle(paper_img, (int(center_x), int(center_y)), 5, (0, 255, 0))
    #     #print(gt)

    for j in range(len(gt)):

        gt_x = gt[j][1]
        gt_y = gt[j][0]

        cv2.circle(canvas_pred, (int(gt_x), int(gt_y)), 1, (255,255,0))
        # cv2.circle(paper_img, (int(gt_x), int(gt_y)), 2, (0, 0, 255), -1)
        # canvas_pred[gt_y][gt_x] = (255, 255, 0)

        #distance = math.sqrt((float(center_x - gt_x)) * (center_x - gt_x) + (float(center_y - gt_y)) * (center_y - gt_y))


        # if distance < min_distance:
        #     min_distance = distance
        #     min_index = j
        #print (min_distance, len(gt), min_index)
        if len(gt)==0:
            break

    #print (j,min_distance, len(gt), min_index, crop_size)
    # if int(gt[min_index][1])>= sigma_map.shape[0] or int(gt[min_index][0])>= sigma_map.shape[1]:
    #     threshold = g_threshold
    # else:
    # threshold = g_threshold
    #     #threshold = min(g_threshold, sigma_map[int(gt[min_index][1])][int(gt[min_index][0])])
    # #print(distance, threshold, min_index, gt[min_index],sigma_map.shape,len(gt))

    # #print(min_index, threshold)
    # if min_distance < threshold:
    #     #(min_index, threshold)
    #     true_positive += 1
    # #cv2.line(canvas, (center_x,center_y), (int(gt[min_index][0]),int(gt[min_index][1])),(0,255,0),1)
    # del gt[min_index]
    #print(canvas_gt.shape)


    cv2.imwrite("visGt/" + fname.split('.')[0]+'.png', canvas_pred)
    #cv2.imwrite("save_result/" + fname[0].split('.')[0] + 'Gt.bmp', canvas_gt)

    #print(number_other, number_crop)

    #precision = (true_positive_crop) / float( number_crop)
    #print(fname[0], threshold, "precision: %.3f"%precision, "ori_pred",len(pred_xy_ori), "refine:", (number_other + number_crop), number_other,number_crop)
    #print(len(contours))
    return  


if __name__ == "__main__":
    main()