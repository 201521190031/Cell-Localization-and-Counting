# coding:utf-8
import sys
import os

import warnings

from utils import save_checkpoint_counter

import torch.nn.functional as F
import torch
import torch.nn as nn
from torch.autograd import Variable
from torchvision import datasets, transforms
import os
import numpy as np
import argparse
import json
import cv2
import dataset
import time
import math
from PIL import Image
from image import *
import scipy.io
import scipy.misc as misc
from scipy.ndimage.filters import gaussian_filter
import os
import random
from hed_model import HED
from rate_model import RATEnet
from fpn import AutoScale
from unet import U_Net
from vgg import VGG
from counter import Counter, Counter_Loss
from centerloss import CenterLoss
import gc
import matplotlib.pyplot as plt
random.seed(10)

from inference_flux import trans_n8, flux_to_skl
from find_contours import findmaxcontours

parser = argparse.ArgumentParser(description='PyTorch CSRNet')
parser.add_argument('--model_id', default=0, type=int, help='id of trained model')

warnings.filterwarnings('ignore')
data_transform={'train':transforms.Compose([transforms.Normalize(mean=[0.246, 0.246],std=[0.685, 0.685])]),
'valid':transforms.Compose([transforms.Normalize(mean=[0.246, 0.246], std=[0.685, 0.685])])}


def main():
    global args, best_prec1
   
    best_prec1 = 1e6
    args = parser.parse_args()
    args.original_lr = 1e-4
    args.lr =   1e-3
    lr = 1e-4
    lr_cent = 0.1
    args.rate_lr = 0.01
    args.batch_size = 3
    args.start_epoch = 0

    args.momentum = 0.95
    args.decay = 5 * 1e-4
    args.start_epoch = 0
    args.epochs = 20000
    args.steps = [-1, 1, 100, 150]
    args.scales = [1, 1, 1, 1]
    args.workers = 4
    args.seed = time.time()
    args.print_freq = 200
    args.infer_thresh = 0.6
    args.task = "saved_model/train32_unet(AdaK+Flip+Counter)_3/"
    if not os.path.exists(args.task):
        os.mkdir(args.task)

    global trancos_train_mask, trancos_test_mask
    with open('./Cellstrain.npy', 'rb') as outfile:
        train_list = np.load(outfile).tolist()

    with open('./Cellsval.npy', 'rb') as outfile:
        val_list = np.load(outfile).tolist()
    print(len(train_list), train_list[0],len(val_list))
    density_value = 3
    os.environ['CUDA_VISIBLE_DEVICES'] = "0"

    rate_model = 1
    class_model = Counter('VGG11')
    class_model = nn.DataParallel(class_model, device_ids=[0])
    class_model = class_model.cuda()
    print('Model:', class_model)
    # criterion = nn.MSELoss().cuda()

    # criterion = nn.BCELoss()
    # center_loss = CenterLoss(num_classes=1, feat_dim=1, use_gpu=True)
    criterion = Counter_Loss()

    optimizer = torch.optim.Adam(class_model.parameters(), args.lr)

    # args.pre = './save_file_baseline_Cells/model_best.pth.tar'
    args.pre = './saved_model/train32_unet(AdaK+Flip+Count(Mask))/counter_best.pth.tar'
    args.pre = None
    if args.pre:
        if os.path.isfile(args.pre):
            print("=> loading checkpoint '{}'".format(args.pre))
            checkpoint = torch.load(args.pre)
            args.start_epoch = checkpoint['epoch']
            best_prec1 = checkpoint['best_prec1']

            model_dict = class_model.state_dict()
            pre_val = checkpoint['state_dict']
            # print(pre_val.items())
            pre_val = {k: v for k, v in pre_val.items() if k in model_dict}
            model_dict.update(pre_val)
            class_model.load_state_dict(model_dict)

            print("=> loaded checkpoint '{}' (epoch {})"
                  .format(args.pre, checkpoint['epoch']))
        else:
            print("=> no checkpoint found at '{}'".format(args.pre))

    print(best_prec1)
    
    for epoch in range(args.start_epoch, args.epochs):
        start = time.time()
        adjust_learning_rate(optimizer, epoch)
        start = time.time()
        train(train_list, class_model, rate_model, criterion, optimizer, epoch, args.task, density_value,
            lr_cent, lr)

        end_1 = time.time()
        prec1 = validate(val_list, class_model, rate_model, args.task, density_value, epoch)
        end_2 = time.time()
        
        print("train time:",end_1-start,"test time:",end_2-end_1)
        is_best = prec1 < best_prec1
        best_prec1 = min(prec1, best_prec1)
        
        print(' * best MAE {mae:.3f} '
              .format(mae=best_prec1))      
        print('Trained model id:',args.model_id)
        save_checkpoint_counter({
            'epoch': epoch + 1,
            'arch': args.pre,
            'state_dict': class_model.state_dict(),
            # 'rate_state_dict': rate_model.state_dict(),
            'best_prec1': best_prec1,
            'optimizer': optimizer.state_dict(),
        }, is_best, args.task, args.model_id)
        end = time.time()


def nl(criterion, input, target):
    target = target.unsqueeze(1)
    # print(input.shape)
    # print(target.shape)
    # input = input.sum()
    # target = target.float()
    # loss = criterion(input, target)
    loss = criterion(input, target)
    
    return loss


def train(Pre_data, model, rate_model, criterion, optimizer, epoch, task_id, density_value, lr_cent, lr):
    losses = AverageMeter()
    batch_time = AverageMeter()
    data_time = AverageMeter()

    train_loader = torch.utils.data.DataLoader(
        dataset.listDataset_Cell_Counter(Pre_data, task_id,
                            shuffle=True,
                            transform=transforms.Compose([
                                transforms.ToTensor(), transforms.Normalize([0.00246], [0.00658])
                            ]),
                            train=True,
                            # seen=model.module.seen,
                            batch_size=args.batch_size,
                            num_workers=args.workers),
        batch_size=args.batch_size,drop_last=False)
    print('epoch %d, processed %d samples, lr %.10f' % (epoch, epoch * len(train_loader.dataset), args.lr))

    model.train()
    end = time.time()
    nums = 0

    # scale_map = [0.8,0.85,0.9,0.95,1.0,1.05,1.10,1.15,1.20,1.25,1.30,1.35,1.40,1.45,1.50]
    for i, (target, k) in enumerate(train_loader):
        # if fname[0] == 'img_0346.h5' or fname[0]=='img_1044.h5' or fname[0]=='img_1201.h5':
        start  = time.time()
        # print('target:',target.max())
        target = 30.0*target
        
        target = target.cuda()
        k = k.cuda()
        # print('target:',target.shape)
        
        Hed_result_5 = model(target)
        # print('pred shape:',Hed_result_5.shape)
        end_1  = time.time()
        
        loss = nl(criterion, Hed_result_5, k)         
        # losses.update(loss.item())
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        batch_time.update(time.time() - end)
        end = time.time()
        data_time.update(time.time() - end)
        end_2 = time.time()

        if i % args.print_freq == 0:

            print('4_Epoch: [{0}][{1}/{2}]\t'
                  'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Data {data_time.val:.3f} ({data_time.avg:.3f})\t'
                  'Loss {loss:.4f} ({loss:.4f})\t'
                .format(
                epoch, i, len(train_loader), batch_time=batch_time,
                data_time=data_time, loss=loss.item()))
            with open('./logs/train_logs/trainlog'+str(args.model_id)+'.txt', 'a+') as f:
                f.write('4_Epoch: [{0}][{1}/{2}]\t'
                  'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Data {data_time.val:.3f} ({data_time.avg:.3f})\t'
                  'Loss {loss:.4f} ({loss:.4f})\t\n'
                .format(
                epoch+1, i, len(train_loader), batch_time=batch_time,
                data_time=data_time, loss=loss.item()))
        

def validate(Pre_data, model, rate_model, task_id, density_value, epoch):
    print('begin test')
    test_loader = torch.utils.data.DataLoader(
        dataset.listDataset_Cell_Counter(Pre_data, task_id,
                            shuffle=False,
                            transform=transforms.Compose([
                                transforms.ToTensor(), transforms.Normalize([0.00246], [0.00658])
                            ]), train=False),batch_size=1)

    model.eval()
    mae = 0

    for i, (target, k) in enumerate(test_loader):
        # for j,img in enumerate(imgs):
        
        start = time.time()
        target = 30.0*target
        target = target.cuda()
        Hed_result_5 = model(target)
        # print('pred shape:', Hed_result_5.shape)
        pre_count = Hed_result_5.detach().cpu().numpy().sum()
        Gt_count = k.sum()
        mae+= abs(pre_count - Gt_count)
    mae = mae/len(test_loader)

    with open('./logs/val_logs/vallog'+str(args.model_id)+'.txt', 'a+') as f:
        f.write('Epoch:{epoch:d} * MAE {mae:.3f}\n'
            .format(epoch=epoch+1, mae=mae))
        print('Epoch:{epoch:d} * MAE {mae:.3f}'
            .format(epoch=epoch+1, mae=mae))

    return mae


def adjust_learning_rate(optimizer, epoch):
    """Sets the learning rate to the initial LR decayed by 10 every 30 epochs"""


class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


if __name__ == '__main__':
    main()
