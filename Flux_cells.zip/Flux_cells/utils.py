import h5py
import torch
import shutil
import numpy as np
import cv2
import os
import scipy.io
import math
from PIL import Image,ImageDraw


def save_results(input_img, gt_data, density_map, output_dir, fname='results.png'):
    input_img = input_img[0][0].astype(np.uint8)
    density_map = 255 * density_map / np.max(density_map)
    gt_data = gt_data.astype(np.long)
    gt_data = 255.0 * gt_data / np.max(gt_data)
    gt_data = gt_data[0][0]
    density_map = density_map[0][0]
    # if density_map.shape[1] != input_img.shape[1]:
    #     density_map = cv2.resize(density_map, (input_img.shape[1],input_img.shape[0]))
    #     gt_data = cv2.resize(gt_data, (input_img.shape[1],input_img.shape[0]))
    #print(gt_data.shape, density_map.shape)
    #result_img = np.hstack((gt_data, density_map))
    #path = os.path.join('.', output_dir, fname).replace('.h5','.bmp')
    #print(path)
    # result_img = result_img.astype(np.uint8)
    # result_img = cv2.applyColorMap(result_img, 11)

    gt_data = gt_data.astype(np.uint8)
    # gt_data = cv2.applyColorMap(gt_data, 11)
    # cv2.imwrite(os.path.join('.', output_dir, fname).replace('.h5','Gt.jpg'), gt_data)

    density_map = density_map.astype(np.uint8)
    # density_map = cv2.applyColorMap(density_map, 11)
    #cv2.imwrite(os.path.join('.', output_dir, fname).replace('.h5','Pred.jpg'), density_map)

    #true_and_pred = np.concatenate((gt_data, density_map), axis=1)
    #cv2.imwrite(os.path.join('.', output_dir, fname).replace('.h5','GtL_PredR.jpg'), true_and_pred)

    #cv2.imwrite(os.path.join('.', output_dir, fname).replace('.jpg', 'fuse.bmp'), result_img)


def save_net(fname, net):
    with h5py.File(fname, 'w') as h5f:
        for k, v in net.state_dict().items():
            h5f.create_dataset(k, data=v.cpu().numpy())


def load_net(fname, net):
    with h5py.File(fname, 'r') as h5f:
        for k, v in net.state_dict().items():
            param = torch.from_numpy(np.asarray(h5f[k]))
            v.copy_(param)


def save_checkpoint_counter(state, is_best, task_id, model_id, filename='checkpoint.pth.tar'):
    torch.save(state, str(task_id) + '/' + filename)
    if is_best:
        # print("save_end")
        shutil.copyfile(str(task_id) + '/' + filename, str(task_id) + '/' + 'counter_best.pth.tar')


def save_checkpoint(state, visi, is_best, task_id, model_id, filename='checkpoint.pth.tar'):
    torch.save(state, str(task_id) + '/' + filename)
    if is_best:
        # print("save_end")
        shutil.copyfile(str(task_id) + '/' + filename, str(task_id) + '/' + 'model_best_1.pth.tar')

    for i in range(len(visi)):
        img = visi[i][0]
        output = visi[i][1]
        target = visi[i][2]
        fname = visi[i][3]
        save_results(img, target, output, str(task_id), fname[0])
g_threshold = 16


def save_true_pred(visi, result_id):

    for i in range(len(visi)):
        img = visi[i][0]
        output = visi[i][1]
        target = visi[i][2]
        fname = visi[i][3]
        save_results(img, target, output, str(result_id), fname[0])

def geneate_knn_map(gt,img):
    k = np.zeros((img.shape[0], img.shape[1]))
    #print(k.shape,img.shape)
    count = 0
    for i in range(0, len(gt)):
        if int(gt[i][1]) < img.shape[0] and int(gt[i][0]) < img.shape[1]:
            k[int(gt[i][1]), int(gt[i][0])] = 1
            count +=1
    #print(len(gt),count)
    pts = np.array(zip(np.nonzero(k)[1], np.nonzero(k)[0]))
    leafsize = 2048
    # build kdtree
    tree = scipy.spatial.KDTree(pts.copy(), leafsize=leafsize)
    # query kdtree
    if len(gt)>=8:
        distances, locations = tree.query(pts, k=8)
    else:
        distances, locations = tree.query(pts, k=2)

    sigma_map = np.zeros(k.shape, dtype=np.float32)
    # pt2d = np.zeros(k.shape,dtype= np.float32)
    for i, pt in enumerate(pts):
        if len(distances) >=8 :

            sigma = (distances[i][0] + distances[i][1] + distances[i][2] + distances[i][3] + distances[i][4] + distances[i][5] + distances[i][6] + distances[i][7])/8.0
            sigma_map[pt[1], pt[0]] = sigma
        else:
            #print("len(distance is ) % .3f"%(len(distances)))
            sigma = (distances[i][0] + distances[i][1])/2.0
            sigma_map[pt[1], pt[0]] = sigma
            #print(sigma)

    return sigma_map



def caculate_precision_2(gt, rate, crop_size, refine_flag, fname, pred_xy_ori, pred_xy_crop):
    ori_gt = gt.copy()
    gt = gt.tolist()
    ori_gt = ori_gt.tolist()

    true_positive = 0
    true_positive_crop = 0
    number_other = 0

    img_path = "../ShanghaiTech_Crowd_Counting_Dataset_baseline/part_A_final/test_data/images/"+fname[0]
    paper_img = cv2.imread(img_path)

    input_img = cv2.imread("./ori_caculate_acu.jpg")
    sigma_map = geneate_knn_map(gt, input_img)
    canvas = np.zeros((input_img.shape[0], input_img.shape[1], 3), dtype="uint8")  +255 # 22
    min_index = 0


    for i in range(len(pred_xy_ori)):

        center_x = int(pred_xy_ori[i][1])
        center_y = int(pred_xy_ori[i][0])

        min_distance = 1e8

        if refine_flag == True:
            if center_x > crop_size[0] and center_x < crop_size[0] + crop_size[2] and center_y >crop_size[
                1] and center_y < crop_size[1] + crop_size[3]:
                number_other += 1
                continue

        cv2.circle(canvas, (int(center_x), int(center_y)), 1, (0, 255, 0))
        #cv2.circle(paper_img, (int(center_x), int(center_y)), 5, (0, 255, 0))

        for j in range(len(gt)):

            gt_x = gt[j][0]
            gt_y = gt[j][1]

            cv2.circle(canvas, (int(gt_x), int(gt_y)), 1, (0,0,255), -1)
            cv2.circle(paper_img, (int(gt_x), int(gt_y)), 2, (0, 0, 255), -1)

            distance = math.sqrt((float(center_x - gt_x)) * (center_x - gt_x) + (float(center_y - gt_y)) * (center_y - gt_y))


            if distance < min_distance:
                min_distance = distance
                min_index = j
            #print (min_distance, len(gt), min_index)

        if len(gt)==0:
            break

        #print (j,min_distance, len(gt), min_index, crop_size)
        if int(gt[min_index][1])>= sigma_map.shape[0] or int(gt[min_index][0])>= sigma_map.shape[1]:
            threshold = g_threshold
        else:
            threshold = g_threshold
            #threshold = min(g_threshold, sigma_map[int(gt[min_index][1])][int(gt[min_index][0])])
        #print(distance, threshold, min_index, gt[min_index],sigma_map.shape,len(gt))

        #print(min_index, threshold)
        if min_distance < threshold:
            #(min_index, threshold)
            true_positive += 1
            cv2.line(canvas, (center_x,center_y), (int(gt[min_index][0]),int(gt[min_index][1])),(0,255,0),1)
            del gt[min_index]

    '''caculate crop region'''
    if refine_flag ==True:
        number_crop = len(pred_xy_crop)
        for i in range(len(pred_xy_crop)):

            center_x = pred_xy_crop[i][1]
            center_y = pred_xy_crop[i][0]
            center_x = center_x/rate.item() + crop_size[0]
            center_y = center_y/rate.item() + crop_size[1]

            min_distance = 1e8

            for j in range(len(gt)):

                gt_x = gt[j][0]
                gt_y = gt[j][1]

                if gt_x < crop_size[0] or gt_x > crop_size[0] + crop_size[2] or gt_y < crop_size[1] or gt_y > crop_size[1] + crop_size[3]:
                    continue

                distance = math.sqrt((float(center_x - gt_x)) * (center_x - gt_x) + (float(center_y - gt_y)) * (center_y - gt_y))
                cv2.circle(canvas, (int(center_x), int(center_y)), 1, (255, 0, 0), -1)
                cv2.circle(paper_img, (int(center_x), int(center_y)), 5, (0, 255, 0))

                cv2.circle(canvas, (int(gt_x), int(gt_y)), 1, (0, 0, 255), -1)
                cv2.circle(paper_img, (int(gt_x), int(gt_y)), 4, (0, 0, 255), -1)

                if distance < min_distance:
                    min_distance = distance
                    min_index_crop = j

            if len(gt) == 0:
                break

            #print(len(crop_gt), sigma_map.shape, int(crop_gt[min_index_crop][1]), int(crop_gt[min_index_crop][0]))
            if int(gt[min_index_crop][1]) >= sigma_map.shape[0] or int(gt[min_index_crop][0]) >= sigma_map.shape[1] :
                threshold = g_threshold
                print("out index")
            else:
                threshold = g_threshold
                #threshold = min(g_threshold, sigma_map[int(gt[min_index_crop][1])][int(gt[min_index_crop][0])])

            #print(threshold,min_distance)
            if min_distance < threshold:
                true_positive_crop += 1
                cv2.line(canvas, (int(center_x), int(center_y)), (int( gt[min_index_crop][0]), int(gt[min_index_crop][1])), (0, 255, 0),1)
                del gt[min_index_crop]


    if refine_flag==True:
        cv2.rectangle(canvas, (crop_size[0],crop_size[1]), (crop_size[0] + crop_size[2], crop_size[1] + crop_size[3]),  (255, 255, 0), 1)
        number_other = len(pred_xy_ori) - number_other
        number_crop = len(pred_xy_crop)
    else:
        number_crop = 0
        number_other = len(pred_xy_ori)


    cv2.imwrite("./middle_process/precision/" + fname[0].split('.')[0]+'.bmp', canvas)
    cv2.imwrite("./middle_process/precision/" + fname[0].split('.')[0] + '_paper.bmp', paper_img)

    #print(number_other, number_crop)
    precision = (true_positive + true_positive_crop)/float(number_other + number_crop)

    #precision = (true_positive_crop) / float( number_crop)
    print(fname[0], threshold, "precision: %.3f"%precision, "ori_pred",len(pred_xy_ori), "refine:", (number_other + number_crop), number_other,number_crop)
    #print(len(contours))
    return  (true_positive + true_positive_crop), (number_other + number_crop)


def caculate_recall_2(gt, rate, crop_size, refine_flag, fname, pred_xy_ori, pred_xy_crop):

    gt = gt.tolist()
    pred_xy_ori = pred_xy_ori.tolist()
    pred_xy_crop = pred_xy_crop.tolist()

    true_positive = 0
    true_positive_crop = 0
    number_other = 0
    number_crop = 0


    input_img = cv2.imread("./ori_caculate_acu.jpg")

    sigma_map = geneate_knn_map(gt,  input_img)
    Denominator = len(gt)

    canvas = np.zeros((input_img.shape[0], input_img.shape[1], 3), dtype="uint8")  +255 # 22
    min_index = 0

    #print(len(contours), len(contours_crop))

    if refine_flag==True:
        cv2.rectangle(canvas, (crop_size[0], crop_size[1]), (crop_size[0] + crop_size[2], crop_size[1] + crop_size[3]), (255, 255, 0), 3)

    count = 0

    for i in range(len(gt)):
        gt_x = gt[i][0]
        gt_y = gt[i][1]
        #
        # number_other +=1
        #
        cv2.circle(canvas, (int(gt_x), int(gt_y)), 1, (0, 0, 255), -1)
        #
        min_distance = 1e8
        for j in range(0, len(pred_xy_ori)):
            #print(len(pred_xy_ori))

            center_x = int(pred_xy_ori[j][1])
            center_y = int(pred_xy_ori[j][0])

            if refine_flag == True:
                if center_x > crop_size[0] and center_x < crop_size[0] + crop_size[2] and center_y > crop_size[1] and center_y < crop_size[1] + crop_size[3]:
                    continue

            distance = math.sqrt((float(center_x - gt_x)) * (center_x - gt_x) + (float(center_y - gt_y)) * (center_y - gt_y))
            cv2.circle(canvas, (center_x, center_y), 1, (255, 0, 0), -1)

            if distance < min_distance:
                min_distance = distance
                min_index = j

        flag_crop = False
        # if gt_x < crop_size[0] or gt_x > crop_size[0] + crop_size[2] or gt_y < crop_size[1] or gt_y > \
        #         crop_size[1] + crop_size[3]:
        #     continue
        count = count +1

        if refine_flag==True:
            for j in range(0, len(pred_xy_crop)):

                center_x = pred_xy_crop[j][1]
                center_y = pred_xy_crop[j][0]
                center_x = int(center_x / rate.item() + crop_size[0])
                center_y = int(center_y / rate.item() + crop_size[1])

                distance = math.sqrt((float(center_x - gt_x)) * (center_x - gt_x) + (float(center_y - gt_y)) * (center_y - gt_y))
                cv2.circle(canvas, (int(center_x), int(center_y)), 1, (255, 0, 0), -1)

                if distance < min_distance:
                    min_distance = distance
                    min_index = j
                    flag_crop = True


        if int(gt[i][1])>= sigma_map.shape[0] or int(gt[i][0])>= sigma_map.shape[1]:
            threshold = g_threshold
        else:
            threshold = g_threshold
            #threshold = min(g_threshold, sigma_map[int(gt[i][1])][int(gt[i][0])])



        if min_distance < threshold and flag_crop==False:
            true_positive += 1
            center_x = int(pred_xy_ori[min_index][1])
            center_y = int(pred_xy_ori[min_index][0])

            cv2.line(canvas, (int(center_x), int(center_y)), (int(gt[i][0]), int(gt[i][1])), (0, 255, 0),1)

            del pred_xy_ori[min_index]

        if min_distance < threshold and flag_crop == True:
            true_positive += 1
            center_x = pred_xy_crop[min_index][1]
            center_y = pred_xy_crop[min_index][0]

            center_x = int(center_x/rate.item() + crop_size[0])
            center_y = int(center_y/rate.item() + crop_size[1])

            cv2.line(canvas, (int(center_x), int(center_y)), (int(gt[i][0]), int(gt[i][1])), (0, 255, 0), 1)
            del pred_xy_crop[min_index]

    #print(true_positive,count)
    if count==0:
        count = 1
    #recall = (true_positive )/float(count)
    cv2.imwrite("./middle_process/recall/" + fname[0].split('.')[0] + '.bmp', canvas)
    #print(fname[0], threshold,  "recall %.3f"%recall, number_other, number_crop)
    #print(len(contours))
    return  true_positive, Denominator

def radExtract(sk):
    rads = np.zeros(sk.shape)
    locs = np.argwhere(sk>0)
    # print('locs:',locs.shape)
    for o, loc in enumerate(locs):
        center_x = min(int(loc[1]), sk.shape[1]-1)
        center_y = min(int(loc[0]), sk.shape[1]-1)
        min_distance = 1e8
        

        for j in range(len(locs)):
            if j == o:
                continue
            cal_x = locs[j][1]
            cal_y = locs[j][0]

            
            distance = math.sqrt((float(center_x - cal_x)) * (center_x - cal_x) + (float(center_y - cal_y)) * (center_y - cal_y))

            if distance < min_distance:
                min_distance = distance
                # min_index = j

        min_distance = min(min_distance, 10)
        rad = max(1, int(0.5*min_distance))
        rads[center_y][center_x] = rad
    return rads


def skel2seg(sk, rad, thresh=0.5, ratio=1):
    '''
    given skeleton and diameter, recover segmentation
    Args:
        sk:    the skeleton map, can be binray or probability map
        rad:   the radius map, should be of the same size as `sk`
        ratio: the ratio multiplied
    Returns:
        an PIL image with drawn circles
    '''
    sk = sk.copy()
    sk[sk < thresh] = 0
    sk[sk >= thresh] = 1
    img = Image.new('L', (sk.shape[1], sk.shape[0]))
    if ratio <= 0.01:
        return Image.fromarray(sk, 'L')
    draw = ImageDraw.Draw(img)
    index = np.argwhere(sk > 0)
    # print('Index:',index.shape)
    for i in range(len(index)):
        y = index[i][0]
        x = index[i][1]
        r = rad[y][x] * float(ratio)
        draw.ellipse([x - r, y - r, x +
                      r, y + r], fill=1)
        
    img = np.asarray(img, dtype=np.uint8)
    return img


def get_flux(skeleton):
    rads = radExtract(skeleton)
    dilmask = skel2seg(skeleton, rads)
    rev = 1-skeleton
    height = rev.shape[0]
    width = rev.shape[1]
    rev = (rev > 0).astype(np.uint8)
    dst, labels = cv2.distanceTransformWithLabels(rev, cv2.DIST_L2, cv2.DIST_MASK_PRECISE, labelType=cv2.DIST_LABEL_PIXEL)
    index = np.copy(labels) 
    index[rev > 0] = 0
    place = np.argwhere(index > 0)

    nearCord = place[labels-1,:]
    x = nearCord[:, :, 0]
    y = nearCord[:, :, 1]
    nearPixel = np.zeros((2, height, width))
    nearPixel[0,:,:] = x
    nearPixel[1,:,:] = y
    grid = np.indices(rev.shape)
    grid = grid.astype(float)
    diff = grid - nearPixel

    dist = np.sqrt(np.sum(diff**2, axis = 0))

    direction = np.zeros((2, height, width), dtype=np.float32)
    direction[0,rev > 0] = np.divide(diff[0,rev > 0], dist[rev > 0])
    direction[1,rev > 0] = np.divide(diff[1,rev > 0], dist[rev > 0])

    direction[0] = direction[0]*(dilmask > 0)
    direction[1] = direction[1]*(dilmask > 0)

    flux = -1*np.stack((direction[0], direction[1]))
    return flux, dilmask


def caculate_precision_baseline(input_image, pred_xy_ori, gt, crop_size, fname, s_dir):
    # input_image = np.squeeze(input_image, 0)
    #cv2.imwrite(fname[0].split('.')[0]+'im.bmp', input_image)
    #input_image = input_image.transpose((1, 2, 0))
    input_image_Rsize = cv2.resize(input_image, (input_image.shape[0], input_image.shape[1]))
    ori_gt = gt.copy()
    gt = gt.tolist()
    ori_gt = ori_gt.tolist()

    true_positive = 0
    true_positive_crop = 0
    number_other = 0
    crop_size = crop_size

    # img_path = "../ShanghaiTech_Crowd_Counting_Dataset_baseline/part_A_final/test_data/images/"+fname[0]
    # paper_img = cv2.imread(img_path)

    #input_img = cv2.imread("./ori_caculate_acu.jpg")
    # sigma_map = geneate_knn_map(gt, input_img)
    canvas_pred = input_image_Rsize.copy()
    canvas_gt = input_image_Rsize.copy()
    print(canvas_gt.shape)
    min_index = 0


    for i in range(len(pred_xy_ori)):

        center_x = int(pred_xy_ori[i][0])
        center_y = int(pred_xy_ori[i][1])
        min_distance = 1e8

        # if refine_flag == True:
        #     if center_x > crop_size[0] and center_x < crop_size[0] + crop_size[2] and center_y >crop_size[
        #         1] and center_y < crop_size[1] + crop_size[3]:
        #         number_other += 1
        #         continue

        cv2.circle(canvas_pred, (int(center_x), int(center_y)), pred_xy_ori[i][2], (0, 255, 0), 1)
        #cv2.circle(paper_img, (int(center_x), int(center_y)), 5, (0, 255, 0))
        #print(gt)

        for j in range(len(gt)):

            gt_x = gt[j][1]
            gt_y = gt[j][0]

            # cv2.circle(canvas_pred, (int(gt_x), int(gt_y)), 5, (0,255,255), 1)
            # cv2.circle(paper_img, (int(gt_x), int(gt_y)), 2, (0, 0, 255), -1)

            distance = math.sqrt((float(center_x - gt_x)) * (center_x - gt_x) + (float(center_y - gt_y)) * (center_y - gt_y))
            #print(distance)


            if distance < min_distance:
                min_distance = distance
                min_index = j
        # print(min_distance)
            #print (min_distance, len(gt), min_index)

        if len(gt)==0:
            break

        #print (j,min_distance, len(gt), min_index, crop_size)
        # if int(gt[min_index][1])>= sigma_map.shape[0] or int(gt[min_index][0])>= sigma_map.shape[1]:
        #     threshold = g_threshold
        # else:
        threshold = g_threshold
            #threshold = min(g_threshold, sigma_map[int(gt[min_index][1])][int(gt[min_index][0])])
        #print(distance, threshold, min_index, gt[min_index],sigma_map.shape,len(gt))

        #print(min_index, threshold)
        if min_distance < threshold:
            #(min_index, threshold)
            true_positive += 1
            #cv2.line(canvas, (center_x,center_y), (int(gt[min_index][0]),int(gt[min_index][1])),(0,255,0),1)
            del gt[min_index]

    number_crop = 0
    number_other = len(pred_xy_ori)
    #print(canvas_gt.shape)


    cv2.imwrite(s_dir + fname, canvas_pred)
    # cv2.imwrite("save_result/" + fname[0].split('dots.h5')[0]+'cell.jpg', input_image)
    #cv2.imwrite("save_result/" + fname[0].split('.')[0] + 'Gt.bmp', canvas_gt)

    #print(number_other, number_crop)
    precision = (true_positive+ true_positive_crop)/float(number_other + number_crop)

    #precision = (true_positive_crop) / float( number_crop)
    #print(fname[0], threshold, "precision: %.3f"%precision, "ori_pred",len(pred_xy_ori), "refine:", (number_other + number_crop), number_other,number_crop)
    #print(len(contours))
    # return  (true_positive + true_positive_crop), (number_other + number_crop), precision
    return precision


def caculate_recall_baseline(input_image, pred_xy_ori, gt, crop_size, fname):

    gt = gt.tolist()
    #pred_xy_ori = pred_xy_ori.tolist()
    #pred_xy_crop = pred_xy_crop.tolist()

    true_positive = 0
    true_positive_crop = 0
    number_other = 0
    number_crop = 0


    # input_img = cv2.imread("./ori_caculate_acu.jpg")

    # sigma_map = geneate_knn_map(gt,  input_img)
    Denominator = len(gt)

    #canvas = np.zeros((input_img.shape[0], input_img.shape[1], 3), dtype="uint8")  +255 # 22
    min_index = 0

    #print(len(contours), len(contours_crop))

    # if refine_flag==True:
    #     cv2.rectangle(canvas, (crop_size[0], crop_size[1]), (crop_size[0] + crop_size[2], crop_size[1] + crop_size[3]), (255, 255, 0), 3)

    count = 0

    for i in range(len(gt)):
        gt_x = gt[i][1]
        gt_y = gt[i][0]
        #
        # number_other +=1
        #
        #cv2.circle(canvas, (int(gt_x), int(gt_y)), 1, (0, 0, 255), -1)
        #
        min_distance = 1e8
        for j in range(0, len(pred_xy_ori)):
            #print(len(pred_xy_ori))

            center_x = int(pred_xy_ori[j][0])
            center_y = int(pred_xy_ori[j][1])

            # if refine_flag == True:
            #     if center_x > crop_size[0] and center_x < crop_size[0] + crop_size[2] and center_y > crop_size[1] and center_y < crop_size[1] + crop_size[3]:
            #         continue

            distance = math.sqrt((float(center_x - gt_x)) * (center_x - gt_x) + (float(center_y - gt_y)) * (center_y - gt_y))
            #cv2.circle(canvas, (center_x, center_y), 1, (255, 0, 0), -1)

            if distance < min_distance:
                min_distance = distance
                min_index = j

        flag_crop = False
        # if gt_x < crop_size[0] or gt_x > crop_size[0] + crop_size[2] or gt_y < crop_size[1] or gt_y > \
        #         crop_size[1] + crop_size[3]:
        #     continue
        count = count +1

        # if refine_flag==True:
        #     for j in range(0, len(pred_xy_crop)):

        #         center_x = pred_xy_crop[j][1]
        #         center_y = pred_xy_crop[j][0]
        #         center_x = int(center_x / rate.item() + crop_size[0])
        #         center_y = int(center_y / rate.item() + crop_size[1])

        #         distance = math.sqrt((float(center_x - gt_x)) * (center_x - gt_x) + (float(center_y - gt_y)) * (center_y - gt_y))
        #         cv2.circle(canvas, (int(center_x), int(center_y)), 1, (255, 0, 0), -1)

        #         if distance < min_distance:
        #             min_distance = distance
        #             min_index = j
        #             flag_crop = True


        # if int(gt[i][1])>= sigma_map.shape[0] or int(gt[i][0])>= sigma_map.shape[1]:
        #     threshold = g_threshold
        # else:
        threshold = g_threshold
            #threshold = min(g_threshold, sigma_map[int(gt[i][1])][int(gt[i][0])])



        if min_distance < threshold and flag_crop==False:
            true_positive += 1
            center_x = int(pred_xy_ori[min_index][1])
            center_y = int(pred_xy_ori[min_index][0])
            del pred_xy_ori[min_index]

            #cv2.line(canvas, (int(center_x), int(center_y)), (int(gt[i][0]), int(gt[i][1])), (0, 255, 0),1)

            # del pred_xy_ori[min_index]

        # if min_distance < threshold and flag_crop == True:
        #     true_positive += 1
        #     center_x = pred_xy_crop[min_index][1]
        #     center_y = pred_xy_crop[min_index][0]

        #     center_x = int(center_x/rate.item() + crop_size[0])
        #     center_y = int(center_y/rate.item() + crop_size[1])

        #     cv2.line(canvas, (int(center_x), int(center_y)), (int(gt[i][0]), int(gt[i][1])), (0, 255, 0), 1)
        #     del pred_xy_crop[min_index]

    #print(true_positive,count)
    if count==0:
        count = 1
    #recall = (true_positive )/float(count)
    #cv2.imwrite("./middle_process/recall/" + fname[0].split('.')[0] + '.bmp', canvas)
    recall = true_positive/float(Denominator)
    #print(fname[0], threshold,  "recall %.3f"%recall, number_other, number_crop)
    #print(len(contours))
    # return  true_positive, Denominator, recall
    return recall


