import sys
import scipy.io as sio
import h5py
import math
import numpy as np
import cv2
import matplotlib.pyplot as plt
plt.switch_backend('agg')
from matplotlib import cm
import os
import glob
#import time
pathim = '../datasets/cells/transxy'
path = '../datasets/cells/transxy'
spath = '../datasets/cells/flux'
if not os.path.exists(spath):
    os.mkdir(spath)

files = glob.glob(os.path.join(pathim, '*cell.png'))
filesgt = glob.glob(os.path.join(path, '*.h5'))
files.sort()
filesgt.sort()
for i in range(len(files)):
    image = cv2.imread(files[i],1)
    image = image[:,:,::-1]
    vector = h5py.File(filesgt[i], 'r')['flux']
    norm = np.sqrt(vector[1,:,:]**2 + vector[0,:,:]**2)
#    print norm.max()
    angle = 180/math.pi*np.arctan2(vector[1,:,:], vector[0,:,:])
    angle=angle*(norm>0.45)
    fig = plt.figure('gt_'+filesgt[i].split('/')[-1].split('.h5')[0],figsize=(15,5))
    ax0 = fig.add_subplot(131)
    ax0.set_title('Image')
    ax0.imshow(image)
    im1 = ax0.imshow(image,cmap=cm.jet)
    ax1 = fig.add_subplot(132)
    ax1.set_title('Norm')
    ax1.set_autoscale_on(True)
    im1 = ax1.imshow(norm,cmap=cm.jet)
    plt.colorbar(im1,shrink=0.9)
    ax2 = fig.add_subplot(133)
    ax2.set_title('Angle')
    ax2.set_autoscale_on(True)
    im2 = ax2.imshow(angle,cmap=cm.jet)
    plt.colorbar(im2,shrink=0.9)
#    t1 = time.time()
    # plt.savefig(spath+'/'+files[i].split('/')[-1])
    plt.savefig(spath+'/'+files[i].split('/')[-1])
#    t2 = time.time()
    plt.close(fig)
#    plt.clf()
#    t3 = time.time()
#    print("{0:.2f} s".format(t2-t1))
#    print("{0:.2f} s".format(t3-t2))
