import cv2
import numpy as np
import scipy.io as sio
import os
import glob

def getskl(save_path, imgpath, gtpath):
    image = cv2.imread(imgpath, 1)
    skl = cv2.imread(gtpath, 0)

    # spoints = np.array(sio.loadmat(gtpath)['detection'])
    # skl = np.zeros((image.shape[0], image.shape[1]))
    # for item in spoints:
    #     y = min(int(item[1]), image.shape[0]-1)
    #     x = min(int(item[0]), image.shape[1]-1)
    #     skl[y][x] = 1
    # inputWeight = (skl > 0).astype(np.float32)[np.newaxis, np.newaxis, ...]
    # skl = 255*(skl > 0).astype(np.uint8)

    # compute ground truth
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (12, 12))
    mask = cv2.dilate(skl, kernel)
    img = 255-skl
    height = img.shape[0]
    width = img.shape[1]
    img = img > 128
    img = img.astype(np.uint8)
    dst, labels = cv2.distanceTransformWithLabels(img, cv2.DIST_L2, cv2.DIST_MASK_PRECISE, labelType=cv2.DIST_LABEL_PIXEL)

    index = np.copy(labels)
    index[img > 0] = 0
    place =  np.argwhere(index > 0)

    nearCord = place[labels-1,:]
    x = nearCord[:, :, 0]
    y = nearCord[:, :, 1]
    nearPixel = np.zeros((2, height, width))
    nearPixel[0,:,:] = x
    nearPixel[1,:,:] = y
    grid = np.indices(img.shape)
    grid = grid.astype(float)
    diff = grid - nearPixel

    dist = np.sqrt(np.sum(diff**2, axis = 0))

    direction = np.zeros((3, height, width), dtype=np.float32)
    direction[0,img > 0] = np.divide(diff[0,img > 0], dist[img > 0])
    direction[1,img > 0] = np.divide(diff[1,img > 0], dist[img > 0])
    direction[2,img > 0] = 1

    direction[0] = direction[0]*(mask > 128)
    direction[1] = direction[1]*(mask > 128)
    direction[2] = direction[2]*(mask > 128)

    # compute weight map
    inputGtxy = np.stack((direction[0], direction[1]))
    #        weights = np.zeros((self.patchSize, self.patchSize), dtype=np.float32)
    #        posRegion = direction[2]>0
    #        weights = 1*posRegion
    #        inputWeight = weights[np.newaxis, ...]

    #return inputImage, inputGtxy, inputWeight
    sio.savemat(os.path.join(save_path, gtpath.split('/')[-1]),{'GTcls':inputGtxy})

path = '../datasets/MBM_data'
save_path = '../datasets/MBM_data/transxy'
if not os.path.exists(save_path):
    os.mkdir(save_path)

gtpaths = glob.glob(os.path.join(path, 'annotations/*.png'))
imgpaths = glob.glob(os.path.join(path, 'source/*.png'))
gtpaths.sort()
imgpaths.sort()
for imgpath, gtpath in zip(imgpaths, gtpaths):
    getskl(save_path, imgpath, gtpath)

