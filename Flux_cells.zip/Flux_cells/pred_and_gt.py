import cv2
import os
import glob
import numpy as np

pred_path = "../datasets/cells/magnitude_and_angle"
gt_path = "../datasets/cells/flux"
predfiles = glob.glob(os.path.join(pred_path, '*dotsmask_angle.png'))
for predpath in predfiles:
    gt = cv2.imread(predpath.replace('dotsmask_angle', 'cell').replace('/magnitude_and_angle/', '/flux/'))
    pred = cv2.imread(predpath)
    gt_and_pred = np.concatenate((gt, pred), 0)
    print(gt_and_pred.shape)
    cv2.imwrite(predpath, gt_and_pred)

print('end')
    
