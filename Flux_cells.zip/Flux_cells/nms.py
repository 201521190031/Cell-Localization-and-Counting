import numpy as np
import math

def nms(dets, d_threshold, size):
    locs = dets.copy()
    min_index = []
    for o, loc in enumerate(dets):
        center_x = min(int(loc[1]), size[1] - 1)
        center_y = min(int(loc[0]), size[0] - 1)
        min_distance = 1e8

        for j in range(o+1, len(locs)):
            cal_x = locs[j][1]
            cal_y = locs[j][0]

            distance = math.sqrt((float(center_x - cal_x)) * (center_x - cal_x) \
                                   + (float(center_y - cal_y)) * (center_y - cal_y))

            if distance <= d_threshold:
                min_index.append(j)


    return min_index
